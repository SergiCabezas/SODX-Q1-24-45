-module(lock2).
-export([start/1]).

start(LockId) ->
    spawn(fun() -> init(LockId) end).

init(LockId) ->
    receive
        {peers, Nodes} ->
            open(LockId, Nodes);
        stop ->
            ok
    end.

open(LockId, Nodes) ->
    receive
        {take, Process, Ref} ->
            PendingRefs = requests(LockId, Nodes),
            wait(LockId, Process, PendingRefs, [], Ref, Nodes);
        {request, Sender, ReqRef, SenderId} when LockId > SenderId ->
            Sender ! {ok, ReqRef},
            open(LockId, Nodes);
        {request, Sender, ReqRef, SenderId} ->
            open_with_waiting(LockId, Nodes, [{Sender, ReqRef, SenderId}]);
        stop ->
            ok
    end.

open_with_waiting(LockId, Nodes, WaitingList) ->
    receive
        {take, Process, Ref} ->
            PendingRefs = requests(LockId, Nodes),
            wait(LockId, Process, PendingRefs, WaitingList, Ref, Nodes);
        {request, Sender, ReqRef, SenderId} ->
            open_with_waiting(LockId, Nodes, [{Sender, ReqRef, SenderId} | WaitingList]);
        stop ->
            ok
    end.

requests(LockId, Nodes) ->
    [send_request(LockId, Node) || Node <- Nodes].

send_request(LockId, Node) ->
    Ref = make_ref(),
    Node ! {request, self(), Ref, LockId},
    Ref.

wait(LockId, Process, [], WaitingList, LockRef, Nodes) ->
    Process ! {taken, LockRef},
    held(LockId, WaitingList, Nodes);

wait(LockId, Process, [Ref | RemainingRefs], WaitingList, LockRef, Nodes) ->
    receive
        {request, Sender, ReqRef, SenderId} ->
            wait(LockId, Process, [Ref | RemainingRefs], [{Sender, ReqRef, SenderId} | WaitingList], LockRef, Nodes);
        {ok, Ref} ->
            UpdatedRefs = lists:delete(Ref, RemainingRefs),
            wait(LockId, Process, UpdatedRefs, WaitingList, LockRef, Nodes);
        release ->
            process_waiting(WaitingList),
            open(LockId, Nodes)
    end.

process_waiting(WaitingList) ->
    lists:foreach(fun({Proc, ReqRef, _}) -> Proc ! {ok, ReqRef} end, WaitingList).

held(LockId, WaitingList, Nodes) ->
    receive
        {request, Sender, ReqRef, SenderId} ->
            held(LockId, [{Sender, ReqRef, SenderId} | WaitingList], Nodes);
        release ->
            process_waiting(WaitingList),
            open(LockId, Nodes)
    end.

