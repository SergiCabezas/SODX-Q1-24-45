-module(lock3).
-export([start/1]).

start(LockId) ->
    spawn(fun() -> init(LockId) end).

init(LockId) ->
    Clock = 0,
    receive
        {peers, Nodes} ->
            open(LockId, Nodes, Clock);
        stop ->
            ok
    end.

open(LockId, Nodes, Clock) ->
    receive
        {take, Process, Ref} ->
            NewClock = Clock + 1,
            PendingRefs = requests(LockId, Nodes, NewClock),
            wait(LockId, Process, PendingRefs, [], Ref, Nodes, NewClock);
        {request, Sender, ReqRef, SenderId, Timestamp} ->
            UpdatedClock = max(Clock, Timestamp) + 1,
            request(LockId, Sender, ReqRef, SenderId, Timestamp, UpdatedClock, Nodes);
        stop ->
            ok
    end.

request(LockId, Sender, ReqRef, SenderId, Timestamp, Clock, Nodes) when LockId > SenderId orelse Clock > Timestamp ->
    Sender ! {ok, ReqRef},
    open(LockId, Nodes, Clock);
request(LockId, Sender, ReqRef, SenderId, Timestamp, Clock, Nodes) ->
    open_with_waiting(LockId, Nodes, [{Sender, ReqRef, SenderId, Timestamp}], Clock).

open_with_waiting(LockId, Nodes, WaitingList, Clock) ->
    receive
        {take, Process, Ref} ->
            NewClock = Clock + 1,
            PendingRefs = requests(LockId, Nodes, NewClock),
            wait(LockId, Process, PendingRefs, WaitingList, Ref, Nodes, NewClock);
        {request, Sender, ReqRef, SenderId, Timestamp} ->
            UpdatedClock = max(Clock, Timestamp) + 1,
            open_with_waiting(LockId, Nodes, [{Sender, ReqRef, SenderId, Timestamp} | WaitingList], UpdatedClock);
        stop ->
            ok
    end.

requests(LockId, Nodes, Clock) ->
    [send_request(LockId, Node, Clock) || Node <- Nodes].

send_request(LockId, Node, Clock) ->
    Ref = make_ref(),
    Node ! {request, self(), Ref, LockId, Clock},
    Ref.

wait(LockId, Process, [], WaitingList, LockRef, Nodes, Clock) ->
    Process ! {taken, LockRef},
    held(LockId, WaitingList, Nodes, Clock);

wait(LockId, Process, [Ref | RemainingRefs], WaitingList, LockRef, Nodes, Clock) ->
    receive
        {request, Sender, ReqRef, SenderId, Timestamp} ->
            UpdatedClock = max(Clock, Timestamp) + 1,
            wait(LockId, Process, [Ref | RemainingRefs], [{Sender, ReqRef, SenderId, Timestamp} | WaitingList], LockRef, Nodes, UpdatedClock);
        {ok, Ref} ->
            wait(LockId, Process, lists:delete(Ref, RemainingRefs), WaitingList, LockRef, Nodes, Clock);
        release ->
            process_waiting(WaitingList),
            open(LockId, Nodes, Clock)
    end.

process_waiting(WaitingList) ->
    lists:foreach(fun({Proc, ReqRef, _, _}) -> Proc ! {ok, ReqRef} end, WaitingList).

held(LockId, WaitingList, Nodes, Clock) ->
    receive
        {request, Sender, ReqRef, SenderId, Timestamp} ->
            UpdatedClock = max(Clock, Timestamp) + 1,
            held(LockId, [{Sender, ReqRef, SenderId, Timestamp} | WaitingList], Nodes, UpdatedClock);
        release ->
            process_waiting(WaitingList),
            open(LockId, Nodes, Clock)
    end.

