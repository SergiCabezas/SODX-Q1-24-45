-module(muty).
-export([start/3, stop/0]).

start(Lock, Sleep, Work) ->
    Nodes = [
        {node1, l1, w1, "John"},
        {node2, l2, w2, "Ringo"},
        {node3, l3, w3, "Paul"},
        {node4, l4, w4, "George"}
    ],

    NodeString = atom_to_list(node()),
    [NodeName | _] = string:tokens(NodeString, "@"),

    case lists:keyfind(list_to_atom(NodeName), 1, Nodes) of
        {NodeId, LockId, WorkerId, WorkerName} ->
            case rpc:call(node(), Lock, start, [LockId]) of
                {ok, LockPid} ->
                    register(LockId, LockPid),
                    LockPid ! {peers, lists:map(fun({N, LId, _, _}) -> {LId, N} end, lists:delete({NodeId, LockId, WorkerId, WorkerName}, Nodes))};
                _Error ->
                    ok
            end,

            case rpc:call(node(), worker, start, [WorkerName, LockId, Sleep, Work]) of
                {ok, WorkerPid} ->
                    register(WorkerId, WorkerPid);
                _Error2 ->
                    ok
            end;
        false ->
            ok
    end,

    ok.

stop() ->
    Nodes = [
        {node1, l1, w1, "John"},
        {node2, l2, w2, "Ringo"},
        {node3, l3, w3, "Paul"},
        {node4, l4, w4, "George"}
    ],

    NodeString = atom_to_list(node()),
    [NodeName | _] = string:tokens(NodeString, "@"),

    case lists:keyfind(list_to_atom(NodeName), 1, Nodes) of
        {_, _, WorkerId, _} ->
            WorkerPid = whereis(WorkerId),
            WorkerPid ! stop;
        false ->
            ok
    end,
    ok.

